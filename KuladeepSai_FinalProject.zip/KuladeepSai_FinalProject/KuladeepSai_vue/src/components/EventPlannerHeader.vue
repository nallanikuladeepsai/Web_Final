<template>
    <header class="header">
        <h1>Turning Moments into Memories!</h1>
    </header>
</template>

<script>
    export default{
        name:"EventPlannerHeader"
    }
</script>

<style>
    .header{
        text-align:center;
    }
</style>